<?php
/**
 * Plugin Name: Eco Filter Sidebar
 * Plugin URI: https://econaturprodukt.ru
 * Description: Боковой фильтр WooCommerce для ЭкоНатурПродукт.
 * Version: 0.5.2
 * Author: ЭкоНатурПродукт
 * Requires Plugins: woocommerce
 */



if (!defined('ABSPATH')) {
    exit;
}

$options = Eco_Filter_Config::get();

/*
|--------------------------------------------------------------------------
| Константы плагина
|--------------------------------------------------------------------------
*/

define('ECO_FILTER_VERSION', '0.5.2');
define('ECO_FILTER_PATH', plugin_dir_path(__FILE__));
define('ECO_FILTER_URL', plugin_dir_url(__FILE__));

/*
|--------------------------------------------------------------------------
| Загрузка классов
|--------------------------------------------------------------------------
*/

require_once ECO_FILTER_PATH . 'includes/class-loader.php';

Eco_Filter_Loader::init();